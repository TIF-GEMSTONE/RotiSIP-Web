Stok Roti :<br/>
   	<?php
    	echo form_dropdown("id_stok_sales",$stok,'',"id='id_stok_sales'");
    ?>